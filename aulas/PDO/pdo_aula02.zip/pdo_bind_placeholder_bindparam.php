<?php
$dsn = 'mysql:host=localhost;dbname=test;charset=utf8;port:3306';
$db_user = 'root';
$db_pass = '';
echo "<pre>";
try{
  $db = new PDO($dsn, $db_user, $db_pass);
  // Prepara a query
  $query = $db->prepare('SELECT *
    FROM filme
    WHERE filme_id = :id
    OR titulo like :titulo');
  //Seta a referência
  $query->bindParam(':id', $id, PDO::PARAM_INT);
  $query->bindParam(':titulo', $titulo, PDO::PARAM_STR);
  //Seta variáveis
  $id = 1;
  $titulo = "A%";
  // Executa a query com os valores
  $query->execute();
  $results = $query->fetchAll(PDO::FETCH_ASSOC);
  var_dump($results);

}catch( PDOException $Exception ) {
  echo $Exception->getMessage();
}
