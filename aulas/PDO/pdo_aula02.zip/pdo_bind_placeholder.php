<?php
$dsn = 'mysql:host=localhost;dbname=test;charset=utf8;port:3306';
$db_user = 'root';
$db_pass = '';
echo "<pre>";
try{
  $db = new PDO($dsn, $db_user, $db_pass);
  // Prepara a query
  $query = $db->prepare('SELECT *
    FROM filme
    WHERE filme_id = :id
    OR titulo like :titulo');
  // Executa a query com os valores
  $params = [
    ':id'=>15,
    ':titulo'=>'A%'
  ];
  $query->execute($params);
  $results = $query->fetchAll(PDO::FETCH_ASSOC);
  var_dump($results);

}catch( PDOException $Exception ) {
  echo $Exception->getMessage();
}
