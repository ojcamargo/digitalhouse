<?php
$dsn = 'mysql:host=localhost;dbname=test;charset=utf8;port:3306';
$db_user = 'root';
$db_pass = '';
echo "<pre>";
try{
  $db = new PDO($dsn, $db_user, $db_pass);
  // Prepara a query
  $query = $db->prepare('SELECT *
    FROM filme
    WHERE filme_id = :id
    OR titulo like :titulo');
  // Define valores
  $id = 1;
  $titulo = "A%";
  // Coloca os valores das variáveis na query
  $query->bindValue(':id', $id, PDO::PARAM_INT);
  $query->bindValue(':titulo', $titulo, PDO::PARAM_STR);
  // Executa a query com os valores
  $query->execute();
  $results = $query->fetchAll(PDO::FETCH_ASSOC);
  var_dump($results);

}catch( PDOException $Exception ) {
  echo $Exception->getMessage();
}
