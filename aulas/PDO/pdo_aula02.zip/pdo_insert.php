<?php
$dsn = 'mysql:host=localhost;dbname=test;charset=utf8;port:3306';
$db_user = 'root';
$db_pass = '';
echo "<pre>";
try{
  $db = new PDO($dsn, $db_user, $db_pass);
  // Prepara a query
  $query = $db->prepare('INSERT INTO ator(primeiro_nome,ultimo_nome)
    VALUES (:primeiro_nome, :ultimo_nome)');
  // Executa a query com os valores
  $query->execute([
    ':primeiro_nome'=>'Chuck',
    ':ultimo_nome'=>'Norris'
  ]);
  // Pega o id da linha inserida
  $id = $db->lastInsertId();
  var_dump($id);

}catch( PDOException $Exception ) {
  echo $Exception->getMessage();
}
