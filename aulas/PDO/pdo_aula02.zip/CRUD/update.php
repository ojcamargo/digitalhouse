<?php
$id = isset($_REQUEST['id'])?$_REQUEST['id']:false;
$dsn = 'mysql:host=localhost;dbname=test;charset=utf8;port:3306';
$db_user = 'root';
$db_pass = '';

try{
  $db = new PDO($dsn, $db_user, $db_pass);
  $query = $db->prepare('SELECT * FROM ator WHERE ator_id = :id');
  $query->execute([':id'=>$id]);
  $ator = $query->fetch(PDO::FETCH_ASSOC);
}catch(PDOException $e){
  echo $e->getMessage();
  die();
}

if($_POST){
  try{
    $query = $db->prepare('UPDATE ator
      SET primeiro_nome = :primeiro_nome,
      ultimo_nome = :ultimo_nome
      WHERE ator_id = :id');
    $query->execute([
      ':primeiro_nome'=>$_POST['primeiro_nome'],
      ':ultimo_nome'=>$_POST['ultimo_nome'],
      ':id'=>$id
    ]);
    header('Location:read.php');
  }catch(PDOException $e){
    echo $e->getMessage();
    die();
  }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Novo Ator</title>
  </head>
  <body>
    <form action="update.php" method="post">
      <input type="hidden" name="id" value="<?php echo $ator['ator_id']; ?>">
      Primeiro nome:
      <input type="text" name="primeiro_nome" value="<?php echo $ator['primeiro_nome']; ?>"><br>
      Último nome:
      <input type="text" name="ultimo_nome" value="<?php echo $ator['ultimo_nome']; ?>"><br>
      <input type="submit" value="Enviar">
    </form>
  </body>
</html>
