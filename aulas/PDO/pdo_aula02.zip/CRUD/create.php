<?php
if($_POST){
  $dsn = 'mysql:host=localhost;dbname=test;charset=utf8;port:3306';
  $db_user = 'root';
  $db_pass = '';
  try{
    $db = new PDO($dsn, $db_user, $db_pass);
    $query = $db->prepare('INSERT INTO ator(primeiro_nome, ultimo_nome)
      VALUES(:primeiro_nome, :ultimo_nome)');
    $query->execute([
      ':primeiro_nome'=>$_POST['primeiro_nome'],
      ':ultimo_nome'=>$_POST['ultimo_nome']
    ]);
    header('Location:read.php');
  }catch(PDOException $e){
    echo $e->getMessage();
    die();
  }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Novo Ator</title>
  </head>
  <body>
    <form action="create.php" method="post">
      Primeiro nome:
      <input type="text" name="primeiro_nome" value=""><br>
      Último nome:
      <input type="text" name="ultimo_nome" value=""><br>
      <input type="submit" value="Enviar">
    </form>
  </body>
</html>
