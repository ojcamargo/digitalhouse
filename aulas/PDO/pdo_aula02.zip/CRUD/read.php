<?php
$dsn = 'mysql:host=localhost;dbname=test;charset=utf8;port:3306';
$db_user = 'root';
$db_pass = '';
try{
  $db = new PDO($dsn, $db_user, $db_pass);
  $query = $db->query('SELECT * FROM ator');
  $atores = $query->fetchAll(PDO::FETCH_ASSOC);
}catch(PDOException $e){
  echo $e->getMessage();
  die();
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Lista de Atores</title>
  </head>
  <body>
    <a href="create.php">Novo Ator</a>
    <table border=1>
      <tr>
        <th>Id</th>
        <th>Primeiro Nome</th>
        <th>Último Nome</th>
        <th>Data Atualização</th>
        <th>Ações</th>
      </tr>
      <?php foreach ($atores as $ator) { ?>
        <tr>
          <td><?php echo $ator['ator_id']; ?></td>
          <td><?php echo $ator['primeiro_nome']; ?></td>
          <td><?php echo $ator['ultimo_nome']; ?></td>
          <td><?php echo $ator['ultima_atualizacao']; ?></td>
          <td>
            <a href="update.php?id=<?php echo $ator['ator_id']; ?>">Editar</a>
            <a href="delete.php?id=<?php echo $ator['ator_id']; ?>">Excluir</a>
          </td>
        </tr>
      <?php } ?>
    </table>
  </body>
</html>
