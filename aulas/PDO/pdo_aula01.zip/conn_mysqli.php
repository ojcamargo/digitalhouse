<?php
/* Conecta no mysql e seleciona Banco de dados */
$conn = mysqli_connect('localhost','root','','test');
/* Verifica conexão */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}
echo "<pre>";
/* Faz query */
$result = mysqli_query($conn, "SELECT * FROM filme LIMIT 5;");
/* Pega resultado 1 linha por vez */
while($row = mysqli_fetch_row($result)){
  echo "mysqli_fetch_row:\r\n";
  var_dump($row);
}
// ------------------------------------------------------
/* Faz query */
$result = mysqli_query($conn, "SELECT * FROM filme LIMIT 5;");
/* Pega resultado 1 linha por vez */
while($row = mysqli_fetch_assoc($result)){
  echo "\r\n\r\nmysqli_fetch_assoc:\r\n";
  var_dump($row);
}
// ------------------------------------------------------
/* Faz query */
$result = mysqli_query($conn, "SELECT * FROM filme LIMIT 5;");
/* Pega resultado 1 linha por vez */
while($row = mysqli_fetch_array($result)){
  echo "\r\n\r\nmysqli_fetch_array:\r\n";
  var_dump($row);
}
// ------------------------------------------------------
/* Fecha conexão */
mysqli_close($conn);
