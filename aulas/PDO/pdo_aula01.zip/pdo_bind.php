<?php
$dsn = 'mysql:host=localhost;dbname=test;charset=utf8;port:3306';
$db_user = 'root';
$db_pass = '';
echo "<pre>";
try{
  $db = new PDO($dsn, $db_user, $db_pass);
  // Prepara a query
  $query = $db->prepare('SELECT *
    FROM filme
    WHERE filme_id = ?
    OR idioma_original_id = ?');
  // Executa a query com o valor 1
  $query->execute([1,15]);
  $results = $query->fetchAll(PDO::FETCH_ASSOC);
  var_dump($results);
  // Executa a query novamente mas com o valor 3
  $query->execute([3,18]);
  $results = $query->fetchAll(PDO::FETCH_ASSOC);
  var_dump($results);

}catch( PDOException $Exception ) {
  echo $Exception->getMessage();
}
