<?php
/* Conecta e verifica conexão */
$conn = mysql_connect('localhost','root','') or die(mysql_error());
/* Seleciona Banco de dados */
mysql_select_db('test');
/* Faz query */
$result = mysql_query("SELECT * FROM filme;");
/* Pega resultado 1 linha por vez */
while($row = mysql_fetch_row($result)){
  var_dump($row);
}
/* Fecha conexão */
mysql_close($conn);
