<?php
$dsn = 'mysql:host=localhost;dbname=test;charset=utf8;port:3306';
$db_user = 'root';
$db_pass = '';
echo "<pre>";
try{
  $db = new PDO($dsn, $db_user, $db_pass);
  // Prepara a query
  $query = $db->prepare('SELECT * FROM filme LIMIT 2');
  // Executa a query
  $query->execute();
  $results = $query->fetchAll(PDO::FETCH_ASSOC);
  var_dump($results);
  // Executa a query novamente
  $query->execute();
  $results = $query->fetchAll(PDO::FETCH_NUM);
  var_dump($results);

}catch( PDOException $Exception ) {
  echo $Exception->getMessage();
}
