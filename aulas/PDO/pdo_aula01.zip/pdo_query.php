<?php
$dsn = 'mysql:host=localhost;dbname=test;charset=utf8;port:3306';
$db_user = 'root';
$db_pass = '';
echo '<pre>';
try{
  $db = new PDO($dsn, $db_user, $db_pass);

  // Realiza uma query de SQL
  $query = $db->query('SELECT * FROM filme');

  // Pega todos os resultados da query
  // $results = $query->fetchAll();
  while($linha = $query->fetch(PDO::FETCH_ASSOC)){
    var_dump($linha);
    $linha = $query->fetch(PDO::FETCH_BOTH);
    var_dump($linha);
  }
  // $coluna = $query->fetchColumn();
// $count = $query->rowCount();

  // PDO::FETCH_ASSOC
  // PDO::FETCH_NUM
  // PDO::FETCH_OBJ

  echo "<pre>";
  // var_dump($results);
  // var_dump($linha);
  echo $coluna."\r\n";
  // echo $count;

}catch( PDOException $Exception ) {
  echo $Exception->getMessage();
}
