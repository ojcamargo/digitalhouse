<?php
// String de conexão:
$dsn = 'mysql:host=localhost;dbname=test;charset=utf8;port:3306';
// Usuário e senha:
$db_user = 'root';
$db_pass = '';
// Conectando com o Banco de Dados:
$db = new PDO($dsn, $db_user, $db_pass);

// Fechar conexão - não é necessário:
//$db = null;
