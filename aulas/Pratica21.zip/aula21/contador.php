<?php
    session_start();
    $_SESSION['contador'] = $_SESSION['contador'] ? : 0;
    if(isset($_POST['mudarContador']) && $_POST['mudarContador'] === 'Aumentar') {
      $_SESSION['contador'] = $_SESSION['contador'] + 1;
    } else if(isset($_POST['mudarContador']) && $_POST['mudarContador'] === 'Reiniciar') {
      $_SESSION['contador'] = 0;
      $_SESSION['cor'] = '';
    } else {
      $_SESSION['contador'] = 0;
    }
    echo $_SESSION['contador'];
?>
<!DOCTYPE html>
<html>
<head>
  <title>Exercicio 1</title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body style="background-color: <?php echo $_SESSION['cor'] ? $_SESSION['cor'] : 'white'; ?>;">
   <form action="contador.php" method="post">
     <input type="submit" name="mudarContador" value="Aumentar" />
     <input type="submit" name="mudarContador" value="Reiniciar" />
   </form>
   <p><a href="cor.php">Exercicio 2</a></p>
</body>
</html>
