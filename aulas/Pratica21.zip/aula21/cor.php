<?php
  session_start();
  $_SESSION["cor"] = "black";
  if(isset($_POST["cor"])) {
    $_SESSION['cor'] = $_POST["cor"];
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Exercicio 2</title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body style="background-color: <?php echo $_SESSION['cor']; ?>;">
   <form action="cor.php" method="post">
     <select name="cor" id="cor" required>
       <option selected disabled value="">Selecione</option>
       <option value="yellow">Amarelo</option>
       <option value="red">Vermelho</option>
       <option value="purple">Roxo</option>
       <option value="lightblue">Cinza</option>
       <option value="gray">Cinza</option>
     </select>
     <button type="submit">Aplicar</button>
   </form>
   <p><a href="contador.php">Voltar</a></p>
</body>
</html>
