<?php
  if($_POST) {
    if(isset($_POST["nome"])) {
      setcookie("nome", $_POST["nome"]);
    }
    if(isset($_POST["idade"])) {
      setcookie("idade", $_POST["idade"]);
    }
  }

?>
<!DOCTYPE html>
<html>
<head>
  <title>Exercicio 3</title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body>
  <form action="idade.php" method="post">
    <p><label for="nome">Nome: <input type="text" name="nome" id="nome" value='<?php echo isset($_COOKIE["nome"]) ? $_COOKIE["nome"] : ""; ?>' /></label></p>
    <p><label for="idade">Idade: <input type="text" name="idade" id="idade" value='<?php echo isset($_COOKIE["idade"]) ? $_COOKIE["idade"] : ""; ?>' /></label></p>
    <button type="submit">Enviar</button>
  </form>
</body>
</html>
