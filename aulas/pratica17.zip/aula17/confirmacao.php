<?php
  $senha = $_POST["senha"];
  $confirmaSenha = $_POST["confirma-senha"];
  $nome = $_POST["name"];
  $idade = $_POST["idade"];

  if(strlen($nome) < 15 && $idade || $idade < 18) {
    header('Location: registro.php?erro=1');
    exit();
  }

  $hobbies = $_POST["hobbies"];
?>
<html>
<body>
<?php
  if($senha != $confirmaSenha) {
?>
  <p>Senhas não conferem</p>
<?php } else { ?>
  <p>Agradecemos a sua inscrição, <?php echo($nome)?>. Você disse que tem <?php echo($_POST["idade"])?> anos. Registramos o seu e-mail: <?php echo($_POST["email"]) ?>. Obrigado!</p>
<?php } ?>
<p>Hobbies</p>
<ul>
<?php foreach ($hobbies as $h): ?>
  <li><?php echo($h); ?></li>
<?php endforeach; ?>
</ul>
</html>
