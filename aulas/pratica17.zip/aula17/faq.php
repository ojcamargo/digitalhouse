<?php
$faq = [
 ["pergunta" => "Quem é?", "resposta" => "Monstro"],
 ["pergunta" => "De onde vem?", "resposta" => "Inferno"],
 ["pergunta" => "O que comem?", "resposta" => "Almas"],
 ["pergunta" => "Como se reproduzem?", "resposta" => "Abduzindo outras almas"]
];

$cor = array('Branco', 'Verde', 'Vermelho');

foreach ($faq as $i) {
    echo ("Pergunta:" . $i["pergunta"] . "<br />Resposta:" . $i["resposta"] . "<br />");
}

echo("Cores: <ul>");
foreach ($cor as $c) {
    echo ("<li>$c</li>");
}
echo("<ul />");
?>
