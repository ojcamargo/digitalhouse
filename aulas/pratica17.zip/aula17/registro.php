<?php
$titulo = "Formulario PHP";
$paises = ["Brasil","Outros"];
$erro = isset($_GET["erro"]) ? $_GET["erro"] : "";
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title><?php echo($titulo); ?></title>
</head>
<body>
    <h1><?php echo($titulo); ?></h1>
    <?php if($erro) { ?>
      <h2>Nome ou idade não foram informados corretamente</h2>
    <?php } ?>
    <div id='fg_membersite'>
        <form id='register' action='confirmacao.php' method='post'>
            <fieldset>
                <legend>Inscreva-se</legend>

                <div class='container'>
                    <label for='name' >Nome completo: </label><br/>
                    <input type='text' name='name' id='name' value='' maxlength="50" required /><br/>
                </div>
                <div class='container'>
                    <label for='email' >E-mail:</label><br/>
                    <input type='email' name='email' id='email' value='' maxlength="50" placeholder="email@dominio.com" required /><br/>
                </div>
                <div class='container'>
                    <label for='idade' >Idade*:</label><br/>
                    <input type='number' name='idade' id='idade' value='' maxlength="50" required /><br/>
                </div>
                <div class='container'>
                    <label for='senha' >senha*:</label><br/>
                    <input type='password' name='senha' id='senha' value='' maxlength="50" required /><br/>
                </div>
                <div class='container'>
                    <label for='confirma-senha' >confirmar senha*:</label><br/>
                    <input type='password' name='confirma-senha' id='confirma-senha' value='' maxlength="50" required /><br/>
                </div>
                <div class='container'>
                  <label for='pais'>Pais:</label><br/>
                  <select id='pais' name='pais' required>
                    <?php foreach ($paises as $key) {
                      echo "<option value=" . $key . ">" . $key . "</option>";
                    }
                    ?>
                  </select>
                </div>
                <div class='container'>
                    <label>Hobbies</label>
                    <label for="hobbie-leitura"><input type='checkbox' name='hobbies[]' id='hobbie-leitura' value='leitura' />Leitura</label>
                    <label for="hobbie-jogos"><input type='checkbox' name='hobbies[]' id='hobbie-jogos' value='jogos' />Jogos</label>
                </div>
                <br>
                <div class='container'>
                  <button type="submit" name="button">Enviar</button>
                </div>


                <small>* campos obrigatórios</small>
            </fieldset>
        </form>

    </body>
</html>
