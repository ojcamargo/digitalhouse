<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title></title>
</head>
<body>
  <h1>Criptografia de senha</h1>
  <?php
    $senha = 123;
    $criptografia = password_hash($senha, PASSWORD_DEFAULT);
    echo("Senha: $senha <br /><br />");
    echo("Senha criptografada: $criptografia");
  ?>
</body>
</html>
