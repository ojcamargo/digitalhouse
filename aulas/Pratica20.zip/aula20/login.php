<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Login</title>
</head>
<body>
  <form action="login.php" method="post">
    <input type="email" name="email" placeholder="e-mail" />
    <input type="password" name="senha" placeholder="senha" />
    <button type="submit" name="enviar">Entrar</button>
  </form>
  <?php
    $emailCorreto = 'ojcamargo@gmail.com';
    $senhaCorreta = '$2y$10$Jmuf5KTbeuNLQc0qTfUNHuphl8w8lmWgIQNNp7Z/EvZsfz2H0wCqC';

    if(isset($_POST['email']) && isset($_POST['senha'])) {
      $email = $_POST['email'];
      $senha = $_POST['senha'];
      if($email === $emailCorreto && password_verify($senha,$senhaCorreta)) {
        echo "Bem vindo! $emailCorreto";
      } else {
        echo "Não foi desta vez! Tente novamente.";
      }
    }
  ?>
</body>
</html>
