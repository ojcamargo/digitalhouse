<?php

  if(isset($_FILES['arquivo'])) {

    $error = $_FILES["arquivo"]["error"];

    if($error === UPLOAD_ERR_OK) {

      $name = $_FILES["arquivo"]["name"];
      $arquivo = $_FILES["arquivo"]["tmp_name"];
      $caminho = 'uploads/' . $name;

      if(file_exists($caminho)) {
        echo "Já existe um arquivo com mesmo nome";
      } else {
        if(move_uploaded_file($arquivo, $caminho)) {
          echo "Arquivo gravado com sucesso";
        } else {
          echo "Falha ao enviar arquivo";
        }
      }
    }
  }

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Upload</title>
  </head>
  <body>
      <form action="upload.php" method="post" enctype="multipart/form-data">
        <label for="arquivo">Arquivo</label>
        <input type="file" name="arquivo" id="arquivo" />
        <br />
        <button type="submit">Enviar</button>
      </form>
  </body>
</html>
