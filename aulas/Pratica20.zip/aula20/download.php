<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Download</title>
  </head>
  <body>
  <?php
  if ($handle = opendir('uploads')) {
    while (false !== ($file = readdir($handle))) {
      if ($file != "." && $file != "..") {
        echo "<a href='uploads/$file' download>$file</a><br/>";
      }
    }
    closedir($handle);
  }
  ?>
  </body>
</html>
