<?php

$caminhoArquivo = "hobbies.txt";
echo "<br/>Abrindo o arquivo<br/>";
$recurso = fopen($caminhoArquivo, "w");
echo "<br/>Escrevendo texto<br/>";
fwrite($recurso,"PORQUE ESTA PORCARIA NÃO ESTA QUEBRANDO LINHA?\r\n");
fwrite($recurso,"ESTA BAGAÇA NÂO FUNCIONA DIREITO\r\n");
echo "<br/>Fechando arquivo<br/>";
fclose($recurso);

echo "<br />Abrindo o arquivo<br/>";
$recurso = fopen($caminhoArquivo,'r');
$tamanho = filesize($caminhoArquivo);
echo "<br/>Lendo arquivo<br/>";
$conteudo = fread($recurso,$tamanho);
echo "<br/>Imprimindo: $conteudo <br/>";
echo "<br/>Fechando arquivo<br/>";
fclose($recurso);

echo "<br/>Criando arquivo atraves de file_put_content<br/>";
$conteudo = "Procurar\r\nCaçar\r\Torturar\r\nMatar\r\nFinalizar";
file_put_contents($caminhoArquivo, $conteudo);

echo "<br/>Abrindo arquivo inteiro com file_content<br/>";
$conteudo = file_get_contents($caminhoArquivo);
echo $conteudo;

echo "<br/>Criando arquivo atraves de file_put_content<br/>";
$conteudo = "Procurar\r\nCaçar\r\nTorturar\r\nMatar\r\nFinalizar";
file_put_contents($caminhoArquivo, $conteudo);

echo "<br/>Lendo arquivo linha por linha com fgets<br/>";
$recurso = fopen("hobbies.txt", "r");
if ($recurso) {
  while (($linha = fgets($recurso)) !== false) {
    echo "$linha <br/>";
  }
}
fclose($recurso);

echo "<br/>Anexar conteudo com file_get_contents e file_put_content<br/>";
$conteudo = file_get_contents($caminhoArquivo);
$conteudo .= "Xingar\r\nOfender\r\nBater\r\nCorrer";
file_put_contents($caminhoArquivo, $conteudo);
echo "<br/>$conteudo";

echo "Exemplo com JSON";
$json = "categorias.json";
$recurso = fopen($json,"r");
$tamanho = filesize($json);
$conteudo = fread($recurso, $tamanho);
fclose($recurso);
echo "<br/>$conteudo<br/>";

$conteudo = json_decode($conteudo, true);

$categorias = $conteudo["categorias"];
foreach ($categorias as $cat) {
  echo("$cat<br/>");
}

echo "<br>Imprimindo usuarios<br/>";
$json = "usuarios.json";
$conteudo = file_get_contents($json);
$conteudo = json_decode($conteudo, true);
$listaUsuarios = $conteudo["zuarios"];
var_dump($listaUsuarios);
?>
