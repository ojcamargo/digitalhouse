<?php
  if($_POST) {
    $email = $_POST["email"];
    $senha = $_POST["senha"];
    $confirmarSenha = $_POST["confirmarSenha"];

    if($senha !== $confirmarSenha) {
      $mensagem = "Senha não confere";
    }
    else {
      $senha = password_hash($senha, PASSWORD_DEFAULT);
      $confirmarSenha = null;
      $arquivo = "login.json";
      $recurso = fopen($arquivo, "a");

      $pessoa = ["email" => $email, "senha" => $senha];
      $pessoa = json_encode($pessoa);
      
      fwrite($recurso, $pessoa);

      fclose($recurso);

      $mensagem = "Dados gravados com sucesso!";
    }
  }
?>
<html>
<body>
  <form name="form1" id="form1" action="password.php" method="post">
    <label for="email">E-mail</label>
    <input type="email" name="email" id="email" placeholder="seuemail@dominio.com" size="100" maxlength="100" required />
    <br>
    <label for="senha">Senha</label>
    <input type="password" name="senha" id="senha" size="100" required />
    <br>
    <label for="confirmarSenha">Digite a senha novamente</label>
    <input type="password" name="confirmarSenha" id="confirmarSenha" size="100" required />
    <br>
    <input name="enviar" id="enviar" type="submit" value="enviar" />
    <?php if(isset($mensagem)) { ?>
      <div style="width: 100%; background-color: red; font-size: 12px; color: white;"><?php echo($mensagem); ?></div>
    <?php } ?>
  </form>
</body>
</html>
